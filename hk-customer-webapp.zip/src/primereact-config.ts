export const PrimeReactConfig = {};
