export enum Routes {
	BASE = '/',
	ABOUT = '/about',
	LOGIN = '/login',
	SIGNUP = '/signup',
	SETTINGS = '/settings',
	PASSWORD_RESET = '/reset-password'
}
