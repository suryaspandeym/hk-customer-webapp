// Google Color Palette
export const COLORS = [
	'#008744',
	'#0057e7',
	'#d62d20',
	'#ffa700',
	'#ffbe0b',
	'#fb5607',
	'#ff006e',
	'#8338ec',
	'#3a86ff'
];
