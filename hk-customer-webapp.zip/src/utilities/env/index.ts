const ENV = {
	API_BASE_PATH: import.meta.env.VITE_API_BASE_PATH,
	AUTH_BASE_DOMAIN: import.meta.env.VITE_AUTH_BASE_DOMAIN,

	// AUTH BASE PATH
	AUTH_BASE_PATH: import.meta.env.VITE_AUTH_BASE_PATH
};

export default ENV;
