export default ['de'];
