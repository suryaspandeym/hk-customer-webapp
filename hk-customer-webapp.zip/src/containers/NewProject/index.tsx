import React from 'react';
export const NewProject = () => {
	return <>NewProject</>;
};

export default NewProject;
