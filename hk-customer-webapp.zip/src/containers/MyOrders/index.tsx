import React from 'react';
export const MyOrders = () => {
	return <>My Orders</>;
};

export default MyOrders;
