export enum ExampleActionType {
	REQUEST = 'REQUEST',
	SUCCESS = 'SUCCESS',
	FAILED = 'FAILED'
}
