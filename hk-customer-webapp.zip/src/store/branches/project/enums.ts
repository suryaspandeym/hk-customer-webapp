export enum ProjectActionType {
	ADD_PROJECT_DETAILS = 'ADD_PROJECT_DETAILS'
}
