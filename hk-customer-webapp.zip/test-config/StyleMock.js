module.exports = {
	process() {
		return 'style-mock';
	}
};
